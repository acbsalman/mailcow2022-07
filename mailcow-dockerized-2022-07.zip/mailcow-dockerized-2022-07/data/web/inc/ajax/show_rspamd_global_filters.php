<?php
session_start();
$_SESSION['show_rspamd_global_filters'] = true;