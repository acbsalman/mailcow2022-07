<?php namespace Sieve;

class SieveScript
{
    // TODO: implement
}
